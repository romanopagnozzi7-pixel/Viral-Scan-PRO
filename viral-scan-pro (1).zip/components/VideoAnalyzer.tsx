
import React, { useState } from 'react';
import { analyzeVideo } from '../services/geminiService';
import { VideoAnalysisResult } from '../types';

const VideoAnalyzer: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VideoAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) { // 20MB limit for demo purposes
        setError("File size too large. Please use a video under 20MB.");
        return;
      }
      setVideoFile(file);
      setError(null);
      setPreviewUrl(URL.createObjectURL(file));
      setResult(null);
    }
  };

  const runAnalysis = async () => {
    if (!videoFile) return;
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(videoFile);
      reader.onloadend = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const data = await analyzeVideo(base64, videoFile.name);
        setResult(data);
        setLoading(false);
      };
    } catch (err) {
      setError("Analysis failed. Please try a different video format (MP4/MOV).");
      setLoading(false);
    }
  };

  const reset = () => {
    setVideoFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
  };

  const StatItem = ({ label, value, color }: { label: string, value: number, color: string }) => (
    <div className="flex flex-col items-center space-y-2">
      <div className="relative w-24 h-24">
        <svg className="w-full h-full" viewBox="0 0 36 36">
          <circle className="stroke-current text-gray-800" strokeWidth="2" fill="none" cx="18" cy="18" r="16" />
          <circle 
            className={`stroke-current ${color} transition-all duration-1000`} 
            strokeWidth="2" 
            strokeDasharray={`${value}, 100`} 
            strokeLinecap="round" 
            fill="none" 
            cx="18" 
            cy="18" 
            r="16" 
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xl font-outfit font-bold">{value}%</span>
        </div>
      </div>
      <span className="text-xs font-bold uppercase tracking-widest text-gray-500">{label}</span>
    </div>
  );

  return (
    <div className="flex flex-col items-center space-y-8 w-full max-w-4xl mx-auto px-4">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-outfit font-bold tracking-tight sm:text-4xl">Viral Video Auditor</h2>
        <p className="text-gray-400 max-w-lg mx-auto">Upload your draft to check retention, sharability, and caption optimization before you post.</p>
      </div>

      <div className="w-full glass-card rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {!previewUrl && (
          <div className="aspect-[9/16] max-w-[320px] mx-auto flex flex-col items-center justify-center border-2 border-dashed border-gray-700 rounded-2xl space-y-4">
            <div className="p-4 bg-indigo-500/10 rounded-full">
               <svg className="w-12 h-12 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
               </svg>
            </div>
            <label className="cursor-pointer bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold transition-all shadow-lg text-center">
              Select Video
              <input type="file" accept="video/*" onChange={handleFileChange} className="hidden" />
            </label>
            <p className="text-xs text-gray-500">MP4, MOV up to 20MB</p>
          </div>
        )}

        {previewUrl && (
          <div className="flex flex-col md:flex-row gap-8">
            <div className="w-full md:w-1/2">
               <div className={`aspect-[9/16] rounded-2xl overflow-hidden bg-black shadow-inner border border-white/5 ${loading ? 'animate-scan' : ''}`}>
                 <video src={previewUrl} controls className="w-full h-full object-contain" />
               </div>
               {!loading && !result && (
                  <div className="mt-6 flex flex-col space-y-3">
                    <button onClick={runAnalysis} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl font-black text-lg tracking-widest shadow-xl transition-all hover:scale-[1.02]">
                      AUDIT VIDEO
                    </button>
                    <button onClick={reset} className="w-full text-gray-400 hover:text-white py-2 text-sm transition">
                      Change Video
                    </button>
                  </div>
               )}
            </div>

            <div className="w-full md:w-1/2 space-y-6">
              {loading && (
                <div className="h-full flex flex-col items-center justify-center space-y-4 py-12">
                   <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                   <p className="font-outfit font-bold text-xl text-indigo-400 tracking-widest">CALCULATING VIRAL METRICS...</p>
                   <p className="text-gray-500 text-sm italic">"Scanning captions, hook, and framing..."</p>
                </div>
              )}

              {result && (
                <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-700">
                  <div className="flex justify-between items-center glass-card p-6 rounded-2xl border-indigo-500/30">
                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Viral Potential</h4>
                      <p className="text-4xl font-black gradient-text">{result.overallScore}%</p>
                    </div>
                    <div className="px-3 py-1 bg-indigo-500/10 text-indigo-400 rounded-lg text-xs font-bold border border-indigo-500/20">
                      PRO REPORT
                    </div>
                  </div>

                  <div className="flex justify-around py-4">
                    <StatItem label="Retention" value={result.retentionRate} color="text-indigo-500" />
                    <StatItem label="Sharable" value={result.sharability} color="text-purple-500" />
                    <StatItem label="Relatable" value={result.relatability} color="text-pink-500" />
                  </div>

                  <div className="space-y-4">
                    <h5 className="font-bold text-lg flex items-center">
                      <svg className="w-5 h-5 mr-2 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                      </svg>
                      Caption & Subtitle Fixes
                    </h5>
                    <div className="glass-card p-4 rounded-xl space-y-3 bg-white/5">
                      <p className="text-sm text-gray-300 italic">"{result.captions.feedback}"</p>
                      <div className="p-3 bg-black/40 rounded-lg border border-white/5">
                        <p className="text-xs text-indigo-400 font-bold mb-1 uppercase tracking-wider">Suggested Text:</p>
                        <p className="text-white text-sm font-medium">{result.captions.suggestion}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                         <span className="text-xs text-gray-500">Recommended Placement:</span>
                         <span className="text-xs font-bold text-pink-400 px-2 py-0.5 bg-pink-400/10 rounded">{result.captions.placement}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {result && (
        <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in duration-1000">
           <div className="glass-card p-6 rounded-2xl border-emerald-500/20">
              <h5 className="font-bold mb-4 text-emerald-400 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                Hook Optimization
              </h5>
              <p className="text-gray-300 text-sm leading-relaxed">{result.hookOptimization}</p>
           </div>
           <div className="glass-card p-6 rounded-2xl border-indigo-500/20">
              <h5 className="font-bold mb-4 text-indigo-400 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
                Viral Checklist
              </h5>
              <ul className="space-y-2">
                {result.generalAdvice.map((advice, i) => (
                  <li key={i} className="text-sm text-gray-400 flex items-center">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mr-2"></span>
                    {advice}
                  </li>
                ))}
              </ul>
           </div>
           <button onClick={reset} className="md:col-span-2 py-4 text-gray-500 hover:text-white font-medium transition">
              Analyze Another Video
           </button>
        </div>
      )}

      {error && (
        <div className="bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-3 rounded-xl w-full text-center">
          {error}
        </div>
      )}
    </div>
  );
};

export default VideoAnalyzer;
