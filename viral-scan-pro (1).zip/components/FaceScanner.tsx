
import React, { useState, useRef, useCallback } from 'react';
import { analyzeFace } from '../services/geminiService';
import { FaceAnalysisResult } from '../types';

const FaceScanner: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<FaceAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [streamActive, setStreamActive] = useState(false);

  const startCamera = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setStreamActive(true);
      }
    } catch (err) {
      setError("Camera access denied. Please upload a photo instead.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      setStreamActive(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        setImage(dataUrl);
        stopCamera();
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const runAnalysis = async () => {
    if (!image) return;
    setLoading(true);
    setResult(null);
    setError(null);
    try {
      const base64 = image.split(',')[1];
      const data = await analyzeFace(base64);
      setResult(data);
    } catch (err) {
      setError("Analysis failed. Try again with a clearer photo.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="flex flex-col items-center space-y-8 w-full max-w-4xl mx-auto px-4">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-outfit font-bold tracking-tight sm:text-4xl">Face Card Scanner</h2>
        <p className="text-gray-400 max-w-lg mx-auto">Upload or take a photo for a brutal, honest rating and professional grooming advice.</p>
      </div>

      <div className="w-full relative glass-card rounded-3xl overflow-hidden p-6 shadow-2xl transition-all duration-300">
        {!image && !streamActive && (
          <div className="aspect-[4/3] w-full flex flex-col items-center justify-center border-2 border-dashed border-gray-700 rounded-2xl space-y-4">
            <div className="p-4 bg-indigo-500/10 rounded-full">
              <svg className="w-12 h-12 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <button onClick={startCamera} className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl font-medium transition">
                Open Camera
              </button>
              <label className="cursor-pointer bg-gray-800 hover:bg-gray-700 text-white px-6 py-2 rounded-xl font-medium transition text-center">
                Upload Photo
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>
        )}

        {streamActive && (
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <div className="absolute bottom-6 left-0 right-0 flex justify-center space-x-4">
              <button onClick={capturePhoto} className="bg-white text-black w-16 h-16 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition">
                <div className="w-12 h-12 rounded-full border-4 border-black"></div>
              </button>
              <button onClick={stopCamera} className="bg-red-500/80 backdrop-blur-md text-white px-6 py-3 rounded-xl font-medium hover:bg-red-600 transition">
                Cancel
              </button>
            </div>
            <div className="absolute inset-0 pointer-events-none border-[1px] border-indigo-500/20">
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-64 border-2 border-indigo-500 rounded-[3rem] opacity-40"></div>
            </div>
          </div>
        )}

        {image && (
          <div className="relative group">
            <div className={`aspect-[4/3] rounded-2xl overflow-hidden ${loading ? 'animate-scan' : ''}`}>
               <img src={image} alt="Target" className="w-full h-full object-cover" />
            </div>
            {!loading && !result && (
              <div className="absolute bottom-6 left-0 right-0 flex justify-center space-x-4">
                <button onClick={runAnalysis} className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-xl font-bold text-lg shadow-xl hover:scale-105 transition-all">
                  SCAN FACE CARD
                </button>
                <button onClick={reset} className="bg-gray-800/90 backdrop-blur-md text-white px-6 py-3 rounded-xl font-medium hover:bg-gray-700 transition">
                  Retake
                </button>
              </div>
            )}
            {loading && (
              <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center space-y-4 rounded-2xl">
                <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                <p className="font-outfit font-bold text-xl tracking-widest text-indigo-400">ANALYZING FEATURES...</p>
              </div>
            )}
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-3 rounded-xl w-full text-center">
          {error}
        </div>
      )}

      {result && (
        <div className="w-full space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass-card p-8 rounded-3xl flex flex-col items-center justify-center text-center space-y-2">
              <span className="text-gray-400 uppercase tracking-widest text-xs font-bold">Face Rating</span>
              <div className="text-7xl font-outfit font-black gradient-text">
                {result.rating}<span className="text-2xl text-gray-600">/10</span>
              </div>
              <div className="px-4 py-1 bg-indigo-500/20 text-indigo-400 rounded-full text-sm font-bold border border-indigo-500/30">
                {result.faceShape}
              </div>
            </div>
            
            <div className="md:col-span-2 glass-card p-8 rounded-3xl space-y-4">
              <h3 className="text-xl font-outfit font-bold">Professional Verdict</h3>
              <p className="text-gray-300 leading-relaxed italic">"{result.summary}"</p>
              <div className="flex flex-wrap gap-2">
                {result.positives.map((pos, i) => (
                  <span key={i} className="text-xs font-bold text-emerald-400 bg-emerald-400/10 px-3 py-1 rounded-full border border-emerald-400/20">
                    ✓ {pos}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="glass-card p-8 rounded-3xl bg-gradient-to-br from-indigo-500/5 to-purple-500/5">
            <h3 className="text-2xl font-outfit font-bold mb-6 flex items-center">
              <svg className="w-6 h-6 mr-3 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1h4v1a2 2 0 11-4 0zM12 14H8a1 1 0 010-2h4a1 1 0 110 2z" />
              </svg>
              Improvement Strategy
            </h3>
            <ul className="space-y-4">
              {result.improvements.map((imp, i) => (
                <li key={i} className="flex items-start space-x-4 p-4 rounded-2xl hover:bg-white/5 transition border border-transparent hover:border-white/10">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-sm">
                    {i + 1}
                  </span>
                  <p className="text-gray-300 font-medium leading-relaxed">{imp}</p>
                </li>
              ))}
            </ul>
            <button onClick={reset} className="mt-8 w-full py-4 text-gray-400 hover:text-white transition font-medium border-t border-white/10">
              Run New Scan
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default FaceScanner;
