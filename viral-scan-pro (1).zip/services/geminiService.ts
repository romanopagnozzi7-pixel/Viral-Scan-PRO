
import { GoogleGenAI, Type } from "@google/genai";
import { FaceAnalysisResult, VideoAnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeFace = async (base64Image: string): Promise<FaceAnalysisResult> => {
  const model = 'gemini-3-flash-preview';
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Image,
          },
        },
        {
          text: "Perform a brutal but constructive 'Face Card' analysis. Provide a rating from 1-10. Be honest. Analyze face shape, symmetry, and grooming. List 3 specific improvements to increase the score. Return the response in strict JSON format.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          rating: { type: Type.NUMBER },
          faceShape: { type: Type.STRING },
          summary: { type: Type.STRING },
          positives: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          improvements: { 
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["rating", "faceShape", "summary", "positives", "improvements"]
      },
    },
  });

  return JSON.parse(response.text || '{}') as FaceAnalysisResult;
};

export const analyzeVideo = async (fileBase64: string, fileName: string): Promise<VideoAnalysisResult> => {
  const model = 'gemini-3-flash-preview';
  
  // Note: For video analysis in a browser without complex backend, we treat the video upload
  // by sending the prompt and if possible a frame or the file if small enough.
  // Gemini 3 Flash can handle video files via parts if the mimeType is correct.
  
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'video/mp4', // assuming mp4, we should dynamically check this
            data: fileBase64,
          },
        },
        {
          text: "Analyze this social media video for viral potential. Evaluate retention rate, sharability, and relatability (0-100%). Check the captions: are they too long? effective? well-placed? Suggest how to make them shorter and where to place them to avoid being covered by UI (like TikTok/Reels UI). Suggest a better hook. Return in JSON.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          overallScore: { type: Type.NUMBER },
          retentionRate: { type: Type.NUMBER },
          sharability: { type: Type.NUMBER },
          relatability: { type: Type.NUMBER },
          captions: {
            type: Type.OBJECT,
            properties: {
              feedback: { type: Type.STRING },
              suggestion: { type: Type.STRING },
              placement: { type: Type.STRING }
            },
            required: ["feedback", "suggestion", "placement"]
          },
          hookOptimization: { type: Type.STRING },
          generalAdvice: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["overallScore", "retentionRate", "sharability", "relatability", "captions", "hookOptimization", "generalAdvice"]
      },
    },
  });

  return JSON.parse(response.text || '{}') as VideoAnalysisResult;
};
