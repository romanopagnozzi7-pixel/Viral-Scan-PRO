
import React, { useState } from 'react';
import { AppTab } from './types';
import FaceScanner from './components/FaceScanner';
import VideoAnalyzer from './components/VideoAnalyzer';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.FACE_SCAN);

  return (
    <div className="min-h-screen bg-[#030712] text-gray-100 flex flex-col">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 glass-card border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h1 className="font-outfit font-black text-2xl tracking-tighter uppercase italic">
              Viral Scan <span className="text-indigo-500">PRO</span>
            </h1>
          </div>
          
          <nav className="hidden md:flex items-center space-x-1 p-1 bg-white/5 rounded-2xl">
            <button 
              onClick={() => setActiveTab(AppTab.FACE_SCAN)}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === AppTab.FACE_SCAN ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
              Face Scan
            </button>
            <button 
              onClick={() => setActiveTab(AppTab.VIDEO_SCAN)}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === AppTab.VIDEO_SCAN ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
            >
              Video Audit
            </button>
          </nav>

          <div className="flex items-center space-x-4">
             <div className="hidden lg:flex flex-col items-end">
               <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">System Status</span>
               <span className="text-[10px] text-emerald-400 flex items-center">
                 <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5 animate-pulse"></span>
                 Neural Engines Online
               </span>
             </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 py-12 pb-32">
        <div className="max-w-7xl mx-auto">
          {activeTab === AppTab.FACE_SCAN ? <FaceScanner /> : <VideoAnalyzer />}
        </div>
      </main>

      {/* Mobile Sticky Navigation */}
      <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-sm">
        <div className="glass-card rounded-2xl p-1 flex shadow-2xl shadow-indigo-500/20">
          <button 
            onClick={() => setActiveTab(AppTab.FACE_SCAN)}
            className={`flex-1 flex flex-col items-center justify-center py-3 rounded-xl transition-all ${activeTab === AppTab.FACE_SCAN ? 'bg-indigo-600 text-white' : 'text-gray-400'}`}
          >
            <svg className="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-[10px] font-bold uppercase tracking-wider">Face Scan</span>
          </button>
          <button 
            onClick={() => setActiveTab(AppTab.VIDEO_SCAN)}
            className={`flex-1 flex flex-col items-center justify-center py-3 rounded-xl transition-all ${activeTab === AppTab.VIDEO_SCAN ? 'bg-indigo-600 text-white' : 'text-gray-400'}`}
          >
            <svg className="w-5 h-5 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-[10px] font-bold uppercase tracking-wider">Video Audit</span>
          </button>
        </div>
      </div>

      {/* Decorative Background Elements */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/10 blur-[120px] rounded-full"></div>
      </div>
    </div>
  );
};

export default App;
