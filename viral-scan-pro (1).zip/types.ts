
export enum AppTab {
  FACE_SCAN = 'face_scan',
  VIDEO_SCAN = 'video_scan'
}

export interface FaceAnalysisResult {
  rating: number;
  faceShape: string;
  summary: string;
  positives: string[];
  improvements: string[];
}

export interface VideoAnalysisResult {
  overallScore: number;
  retentionRate: number;
  sharability: number;
  relatability: number;
  captions: {
    feedback: string;
    suggestion: string;
    placement: string;
  };
  hookOptimization: string;
  generalAdvice: string[];
}
