
import React, { useState, useRef, useCallback } from 'react';
import { ScannerLayout } from './components/ScannerLayout';
import { TrialBanner } from './components/TrialBanner';
import { analyzeFace, analyzeVideo } from './services/geminiService';
import { FaceAnalysis, VideoAnalysis, ScanType } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ScanType>('face');
  const [loading, setLoading] = useState(false);
  const [faceResult, setFaceResult] = useState<FaceAnalysis | null>(null);
  const [videoResult, setVideoResult] = useState<VideoAnalysis | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const resetState = () => {
    setFaceResult(null);
    setVideoResult(null);
    setPreviewUrl(null);
    setLoading(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
    
    // Clear results when new file selected
    setFaceResult(null);
    setVideoResult(null);
  };

  const captureFrameFromVideo = useCallback((): string | null => {
    if (!videoRef.current || !canvasRef.current) return null;
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg').split(',')[1];
  }, []);

  const runAnalysis = async () => {
    if (!previewUrl) return;
    setLoading(true);

    try {
      if (activeTab === 'face') {
        const base64 = previewUrl.split(',')[1];
        const res = await analyzeFace(base64);
        setFaceResult(res);
      } else {
        // Video analysis: extract current frame
        const base64Frame = captureFrameFromVideo();
        if (!base64Frame) throw new Error("Could not capture video frame");
        const res = await analyzeVideo(base64Frame, "User social media video submission");
        setVideoResult(res);
      }
    } catch (error) {
      console.error("Analysis failed:", error);
      alert("Analysis failed. Please check your connection and API key.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen pb-32 bg-slate-950 text-slate-100 selection:bg-indigo-500/30">
      {/* Header */}
      <nav className="border-b border-white/5 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <i className="fa-solid fa-bolt text-xl"></i>
            </div>
            <span className="text-xl font-black tracking-tighter uppercase italic gradient-text">Viral Scan PRO</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => { setActiveTab('face'); resetState(); }}
              className={`text-sm font-semibold transition-colors ${activeTab === 'face' ? 'text-indigo-400' : 'text-slate-400 hover:text-white'}`}
            >
              Face Scanner
            </button>
            <button 
              onClick={() => { setActiveTab('video'); resetState(); }}
              className={`text-sm font-semibold transition-colors ${activeTab === 'video' ? 'text-indigo-400' : 'text-slate-400 hover:text-white'}`}
            >
              Video Analyzer
            </button>
            <button className="bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-full text-sm font-bold border border-white/10 transition-all">
              Pricing
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-8">
        {activeTab === 'face' ? (
          <ScannerLayout 
            title="Face Card Scanner" 
            description="Honest AI evaluation of your visuals. No filters, no lies."
            icon="fa-solid fa-id-card"
          >
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex flex-col gap-4">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-[3/4] rounded-2xl border-2 border-dashed border-slate-700 bg-slate-900/50 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500/50 transition-all group overflow-hidden relative"
                >
                  {previewUrl ? (
                    <img src={previewUrl} className="w-full h-full object-cover" alt="Preview" />
                  ) : (
                    <>
                      <i className="fa-solid fa-cloud-arrow-up text-4xl text-slate-600 mb-4 group-hover:scale-110 transition-transform"></i>
                      <p className="text-slate-500 font-medium">Upload your best face card</p>
                    </>
                  )}
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileUpload}
                  />
                </div>
                <button
                  disabled={!previewUrl || loading}
                  onClick={runAnalysis}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 py-4 rounded-xl font-black uppercase tracking-wider text-lg shadow-xl shadow-indigo-600/20 transition-all active:scale-95"
                >
                  {loading ? (
                    <span className="flex items-center justify-center gap-2">
                      <i className="fa-solid fa-circle-notch animate-spin"></i>
                      Scanning Reality...
                    </span>
                  ) : "Analyze My Face"}
                </button>
              </div>

              <div className="flex flex-col gap-6">
                {faceResult ? (
                  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="bg-slate-900 rounded-2xl p-6 border border-white/5 relative overflow-hidden">
                      <div className="absolute top-0 right-0 p-4 opacity-10">
                        <i className="fa-solid fa-star text-6xl"></i>
                      </div>
                      <h3 className="text-sm font-bold text-indigo-400 uppercase tracking-widest mb-1">Face Rating</h3>
                      <div className="flex items-baseline gap-2">
                        <span className="text-6xl font-black">{faceResult.rating}</span>
                        <span className="text-slate-500 font-bold">/ 10</span>
                      </div>
                      <p className="mt-2 text-slate-400 font-medium italic">"{faceResult.honestyLevel}"</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl">
                        <h4 className="text-emerald-400 font-bold text-xs uppercase mb-3">Strengths</h4>
                        <ul className="space-y-2">
                          {faceResult.strengths.map((s, i) => (
                            <li key={i} className="text-xs text-emerald-100 flex items-start gap-2">
                              <i className="fa-solid fa-check mt-0.5"></i> {s}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-xl">
                        <h4 className="text-rose-400 font-bold text-xs uppercase mb-3">Weaknesses</h4>
                        <ul className="space-y-2">
                          {faceResult.weaknesses.map((w, i) => (
                            <li key={i} className="text-xs text-rose-100 flex items-start gap-2">
                              <i className="fa-solid fa-xmark mt-0.5"></i> {w}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="bg-slate-900 border border-white/5 p-6 rounded-2xl">
                      <h4 className="text-indigo-400 font-bold text-xs uppercase mb-4">Improvement Roadmap</h4>
                      <div className="space-y-3">
                        {faceResult.improvements.map((imp, i) => (
                          <div key={i} className="flex gap-4 items-start">
                            <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center shrink-0 text-[10px] font-bold">
                              {i + 1}
                            </div>
                            <p className="text-sm text-slate-300">{imp}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="bg-indigo-600/10 border border-indigo-600/20 p-4 rounded-xl">
                       <p className="text-xs font-bold text-indigo-300 uppercase mb-1">The Vibe</p>
                       <p className="text-sm">{faceResult.vibe}</p>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 border border-white/5 rounded-2xl bg-slate-900/30">
                    <i className="fa-solid fa-face-viewfinder text-5xl text-slate-700 mb-4"></i>
                    <h3 className="text-xl font-bold mb-2">Awaiting Subject</h3>
                    <p className="text-slate-500 text-sm">Upload a clear photo to see where you stand. Our AI doesn't hold back.</p>
                  </div>
                )}
              </div>
            </div>
          </ScannerLayout>
        ) : (
          <ScannerLayout 
            title="Video Viral Analyzer" 
            description="Optimize for the algorithm. Predict retention, fix captions, go viral."
            icon="fa-solid fa-film"
          >
            <div className="grid md:grid-cols-2 gap-8">
              <div className="flex flex-col gap-4">
                <div 
                  onClick={() => !previewUrl && fileInputRef.current?.click()}
                  className={`aspect-video rounded-2xl border-2 border-dashed ${previewUrl ? 'border-indigo-500/30' : 'border-slate-700'} bg-slate-900/50 flex flex-col items-center justify-center cursor-pointer group overflow-hidden relative`}
                >
                  {previewUrl ? (
                    <video 
                      ref={videoRef}
                      src={previewUrl} 
                      className="w-full h-full object-cover" 
                      controls 
                      onLoadedData={() => {
                        // Just as a helper for analysis
                      }}
                    />
                  ) : (
                    <>
                      <i className="fa-solid fa-video text-4xl text-slate-600 mb-4 group-hover:scale-110 transition-transform"></i>
                      <p className="text-slate-500 font-medium">Upload MP4 / MOV Video</p>
                    </>
                  )}
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="video/*" 
                    onChange={handleFileUpload}
                  />
                  {previewUrl && (
                    <button 
                      onClick={(e) => { e.stopPropagation(); resetState(); }} 
                      className="absolute top-2 right-2 bg-black/60 hover:bg-black/80 w-8 h-8 rounded-full flex items-center justify-center"
                    >
                      <i className="fa-solid fa-times text-xs"></i>
                    </button>
                  )}
                </div>

                <div className="bg-slate-900/80 p-4 rounded-xl border border-white/5">
                   <p className="text-[10px] text-indigo-400 font-black uppercase mb-2 tracking-widest">Viral Tip</p>
                   <p className="text-xs text-slate-400">The algorithm loves high-contrast visuals and quick cuts. Pause the video at the most important moment before hitting "Scan Content".</p>
                </div>

                <button
                  disabled={!previewUrl || loading}
                  onClick={runAnalysis}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 py-4 rounded-xl font-black uppercase tracking-wider text-lg shadow-xl shadow-indigo-600/20 transition-all active:scale-95"
                >
                  {loading ? (
                    <span className="flex items-center justify-center gap-2">
                      <i className="fa-solid fa-spinner animate-spin"></i>
                      Predicting Virality...
                    </span>
                  ) : "Scan Video Stats"}
                </button>
                <canvas ref={canvasRef} className="hidden" />
              </div>

              <div className="flex flex-col gap-6">
                {videoResult ? (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500">
                    <div className="grid grid-cols-3 gap-3">
                      <div className="bg-slate-900 p-4 rounded-xl border border-white/5 text-center">
                        <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Retention</p>
                        <p className="text-2xl font-black text-indigo-400">{videoResult.retentionScore}%</p>
                      </div>
                      <div className="bg-slate-900 p-4 rounded-xl border border-white/5 text-center">
                        <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Shares</p>
                        <p className="text-2xl font-black text-emerald-400">{videoResult.sharabilityScore}%</p>
                      </div>
                      <div className="bg-slate-900 p-4 rounded-xl border border-white/5 text-center">
                        <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Relatable</p>
                        <p className="text-2xl font-black text-purple-400">{videoResult.relatabilityScore}%</p>
                      </div>
                    </div>

                    <div className="bg-indigo-600/10 border border-indigo-600/20 p-5 rounded-2xl relative">
                      <div className="absolute top-4 right-4 bg-indigo-600 px-2 py-0.5 rounded text-[10px] font-black uppercase">
                        {videoResult.viralPotential} Viral Potential
                      </div>
                      <h4 className="text-sm font-bold mb-2">Hook Analysis</h4>
                      <p className="text-sm text-slate-300 leading-relaxed">{videoResult.hookStrength}</p>
                    </div>

                    <div className="bg-slate-900 border border-white/5 p-6 rounded-2xl">
                      <h4 className="text-emerald-400 font-bold text-xs uppercase mb-4">Caption Correction</h4>
                      <div className="space-y-4">
                        <div className="p-3 bg-slate-800/50 rounded-lg border border-white/5">
                          <p className="text-[10px] font-bold text-rose-400 uppercase mb-1">Current/Basic</p>
                          <p className="text-xs text-slate-500 line-through italic">{videoResult.captionImprovements.original || "No caption detected"}</p>
                        </div>
                        <div className="p-3 bg-emerald-500/5 rounded-lg border border-emerald-500/20">
                          <p className="text-[10px] font-bold text-emerald-400 uppercase mb-1">Suggested (Viral Hook)</p>
                          <p className="text-sm text-emerald-50 font-bold">"{videoResult.captionImprovements.suggested}"</p>
                        </div>
                        <div className="flex gap-4">
                          <div className="flex-1">
                            <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Placement</p>
                            <p className="text-xs text-slate-300">{videoResult.captionImprovements.placement}</p>
                          </div>
                          <div className="flex-1">
                            <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Reasoning</p>
                            <p className="text-xs text-slate-300">{videoResult.captionImprovements.reasoning}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900 border border-white/5 p-6 rounded-2xl">
                      <h4 className="text-indigo-400 font-bold text-xs uppercase mb-4">Pacing & Flow Improvements</h4>
                      <ul className="space-y-2">
                        {videoResult.pacingTips.map((tip, i) => (
                          <li key={i} className="text-xs text-slate-300 flex items-start gap-3">
                            <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0"></div>
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 border border-white/5 rounded-2xl bg-slate-900/30">
                    <i className="fa-solid fa-chart-line text-5xl text-slate-700 mb-4"></i>
                    <h3 className="text-xl font-bold mb-2">Algorithm Simulator</h3>
                    <p className="text-slate-500 text-sm">Upload your draft content. We'll tell you if it's a flop or a banger before you post.</p>
                  </div>
                )}
              </div>
            </div>
          </ScannerLayout>
        )}
      </main>

      {/* Footer Branding */}
      <footer className="max-w-7xl mx-auto px-4 py-12 border-t border-white/5 flex flex-col items-center text-center opacity-50">
        <p className="text-xs font-bold uppercase tracking-widest text-slate-600 mb-2">Designed for content creators</p>
        <p className="text-[10px]">&copy; {new Date().getFullYear()} Viral Scan PRO. All rights reserved.</p>
      </footer>

      {/* Persistent CTA */}
      <TrialBanner />
    </div>
  );
};

export default App;
