
import { GoogleGenAI, Type } from "@google/genai";
import { FaceAnalysis, VideoAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const analyzeFace = async (imageBase64: string): Promise<FaceAnalysis> => {
  const model = "gemini-3-flash-preview";
  
  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: imageBase64,
            },
          },
          {
            text: "Analyze this face card. Be brutally honest but constructive. Provide a rating from 1 to 10. List strengths, clear weaknesses (what's holding them back), and specific improvements (skincare, grooming, angles, etc.). Return as JSON.",
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          rating: { type: Type.NUMBER },
          honestyLevel: { type: Type.STRING },
          strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
          weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
          improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
          vibe: { type: Type.STRING },
        },
        required: ["rating", "honestyLevel", "strengths", "weaknesses", "improvements", "vibe"],
      },
    },
  });

  return JSON.parse(response.text || "{}");
};

export const analyzeVideo = async (frameBase64: string, context: string): Promise<VideoAnalysis> => {
  const model = "gemini-3-flash-preview";

  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: frameBase64,
            },
          },
          {
            text: `Analyze this social media video content. Context provided: ${context}. 
            Evaluate retention, sharability, and relatability on a scale of 0-100. 
            Suggest improvements for captions (shorter/more effective), placement, and hook. 
            Return the results in the specified JSON format.`,
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          retentionScore: { type: Type.NUMBER },
          sharabilityScore: { type: Type.NUMBER },
          relatabilityScore: { type: Type.NUMBER },
          hookStrength: { type: Type.STRING },
          captionImprovements: {
            type: Type.OBJECT,
            properties: {
              original: { type: Type.STRING },
              suggested: { type: Type.STRING },
              placement: { type: Type.STRING },
              reasoning: { type: Type.STRING },
            },
            required: ["original", "suggested", "placement", "reasoning"],
          },
          pacingTips: { type: Type.ARRAY, items: { type: Type.STRING } },
          viralPotential: { type: Type.STRING },
        },
        required: ["retentionScore", "sharabilityScore", "relatabilityScore", "hookStrength", "captionImprovements", "pacingTips", "viralPotential"],
      },
    },
  });

  return JSON.parse(response.text || "{}");
};
