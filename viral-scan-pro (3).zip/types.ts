
export interface FaceAnalysis {
  rating: number;
  honestyLevel: string;
  strengths: string[];
  weaknesses: string[];
  improvements: string[];
  vibe: string;
}

export interface VideoAnalysis {
  retentionScore: number;
  sharabilityScore: number;
  relatabilityScore: number;
  hookStrength: string;
  captionImprovements: {
    original: string;
    suggested: string;
    placement: string;
    reasoning: string;
  };
  pacingTips: string[];
  viralPotential: "Low" | "Medium" | "High" | "Extremely High";
}

export type ScanType = 'face' | 'video';
