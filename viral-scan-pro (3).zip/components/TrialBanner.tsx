
import React from 'react';

export const TrialBanner: React.FC = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-indigo-600 text-white py-3 px-4 flex flex-col md:flex-row items-center justify-center gap-4 z-50 animate-pulse-slow">
      <div className="flex items-center gap-2">
        <span className="bg-white text-indigo-600 text-xs font-bold px-2 py-0.5 rounded-full uppercase">Limited Offer</span>
        <p className="text-sm font-medium">30-Day Free Trial of Viral Scan PRO available now!</p>
      </div>
      <div className="flex items-center gap-4">
        <span className="text-sm opacity-90 font-mono">Only $4.99 AUD / month</span>
        <button className="bg-white text-indigo-600 hover:bg-indigo-50 px-6 py-1.5 rounded-full font-bold text-sm transition-all shadow-lg active:scale-95">
          Start Free Trial
        </button>
      </div>
    </div>
  );
};
