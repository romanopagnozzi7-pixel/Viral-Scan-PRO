
import React from 'react';

interface ScannerLayoutProps {
  title: string;
  description: string;
  icon: string;
  children: React.ReactNode;
}

export const ScannerLayout: React.FC<ScannerLayoutProps> = ({ title, description, icon, children }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-6">
        <div className="p-4 bg-indigo-500/20 rounded-2xl">
          <i className={`${icon} text-3xl text-indigo-400`}></i>
        </div>
        <div>
          <h1 className="text-3xl font-bold">{title}</h1>
          <p className="text-slate-400">{description}</p>
        </div>
      </div>
      <div className="bg-slate-800/50 backdrop-blur-md border border-slate-700 rounded-3xl p-6 shadow-2xl">
        {children}
      </div>
    </div>
  );
};
